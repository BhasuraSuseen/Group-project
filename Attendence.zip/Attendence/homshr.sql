/*
Navicat MySQL Data Transfer

Source Server         : asas
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : homshr

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2016-09-10 21:10:49
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `attleave`
-- ----------------------------
DROP TABLE IF EXISTS `attleave`;
CREATE TABLE `attleave` (
  `Date` date NOT NULL,
  `Attend` int(1) NOT NULL,
  `Leave` varchar(200) DEFAULT NULL,
  `LeaveType` varchar(20) DEFAULT NULL,
  `ReqType` varchar(20) DEFAULT NULL,
  `Employee_Nic` varchar(20) NOT NULL,
  KEY `fk_AttLeave_Employee_idx` (`Employee_Nic`),
  CONSTRAINT `fk_AttLeave_Employee` FOREIGN KEY (`Employee_Nic`) REFERENCES `employee` (`Nic`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of attleave
-- ----------------------------
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '835123432V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '835123452V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123410V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123411V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123424V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123425V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123426V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123427V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123433V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123434V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123436V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123442V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123447V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123448V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123449V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123450V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123451V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123452V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123453V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123454V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123455V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123456V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123457V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123458V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123460V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123461V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123462V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123463V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123464V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123465V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123466V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123467V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123468V');
INSERT INTO `attleave` VALUES ('2016-09-06', '1', null, null, null, '851123469V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123470V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123471V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123472V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123473V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123474V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123475V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123476V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123477V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123479V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123480V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123481V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123482V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123483V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123484V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123485V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123486V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123487V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123488V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123489V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123490V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123491V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123492V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123493V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123494V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123495V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123496V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123497V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123498V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '851123499V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123412V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123413V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123414V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123415V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123416V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123417V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123418V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123419V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123420V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123421V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123422V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123423V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123428V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123429V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123430V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123431V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123435V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123437V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123438V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123439V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123440V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123441V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123443V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123445V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123446V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123451V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123453V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123454V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123455V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123457V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123458V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '855123459V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '931678987V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '931881477V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '931991476V');
INSERT INTO `attleave` VALUES ('2016-09-06', '0', null, null, null, '931991478V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '835123432V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '835123452V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123410V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '851123411V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '851123424V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123425V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '851123426V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123427V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123433V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123434V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123436V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '851123442V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123447V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123448V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123449V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123450V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123451V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123452V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123453V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123454V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123455V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123456V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123457V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123458V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123460V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123461V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123462V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123463V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123464V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123465V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123466V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123467V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123468V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123469V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123470V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123471V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123472V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123473V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123474V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123475V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123476V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123477V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123479V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123480V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123481V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123482V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123483V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123484V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123485V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123486V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123487V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123488V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123489V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123490V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123491V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123492V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123493V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123494V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123495V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123496V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123497V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123498V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '851123499V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123412V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123413V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123414V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123415V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123416V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123417V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123418V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123419V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123420V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123421V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123422V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123423V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123428V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123429V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123430V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123431V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123435V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123437V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123438V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123439V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123440V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123441V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123443V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123445V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123446V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123451V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123453V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123454V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '855123455V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123457V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123458V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '855123459V');
INSERT INTO `attleave` VALUES ('2016-09-07', '1', null, null, null, '931678987V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '931881477V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '931991476V');
INSERT INTO `attleave` VALUES ('2016-09-07', '0', null, null, null, '931991478V');
INSERT INTO `attleave` VALUES ('2016-09-08', '1', null, null, null, '835123432V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '835123452V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123410V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123411V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123424V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123425V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123426V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123427V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123433V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123434V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123436V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123442V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123447V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123448V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123449V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123450V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123451V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123452V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123453V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123454V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123455V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123456V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123457V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123458V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123460V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123461V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123462V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123463V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123464V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123465V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123466V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123467V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123468V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123469V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123470V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123471V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123472V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123473V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123474V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123475V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123476V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123477V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123479V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123480V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123481V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123482V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123483V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123484V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123485V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123486V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123487V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123488V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123489V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123490V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123491V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123492V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123493V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123494V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123495V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123496V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123497V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123498V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '851123499V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123412V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123413V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123414V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123415V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123416V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123417V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123418V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123419V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123420V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123421V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123422V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123423V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123428V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123429V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123430V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123431V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123435V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123437V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123438V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123439V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123440V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123441V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123443V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123445V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123446V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123451V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123453V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123454V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123455V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123457V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123458V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '855123459V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '931678987V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '931881477V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '931991476V');
INSERT INTO `attleave` VALUES ('2016-09-08', '0', null, null, null, '931991478V');

-- ----------------------------
-- Table structure for `employee`
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `Nic` varchar(20) NOT NULL,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Dob` date NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `Salary` varchar(20) NOT NULL,
  `ContactNo` varchar(15) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`Nic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES ('835123432V', 'AMILA', 'ERANGA ', '1985-02-02', 'M', '', '12345', '711234532', 'No.93,Temple Rd,Colombo 8');
INSERT INTO `employee` VALUES ('835123452V', 'SADUN', 'ADHIKARI ', '1983-01-03', 'M', '', '27300', '781234562', 'No.26,Temple Rd,Panadura');
INSERT INTO `employee` VALUES ('851123410V', 'HANSIKA', 'BOGAHAPITIYA ', '1985-01-11', 'F', '', '20000', '771234510', 'No.203,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('851123411V', 'PAWANI', 'CHINTHAKI ', '1985-01-12', 'F', '', '49000', '711234511', 'No.23,Temple Rd,Maharagama');
INSERT INTO `employee` VALUES ('851123424V', 'PIYUMI', 'DINUKA ', '1985-01-25', 'F', '', '68000', '711234524', 'No.203/1,Abeywickrama Rd,Panadura');
INSERT INTO `employee` VALUES ('851123425V', 'KASUNI', 'DISSANAYAKA ', '1985-01-26', 'F', '', '54000', '711234525', 'No.90,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('851123426V', 'HARINI', 'DISSANAYAKE ', '1985-01-27', 'F', '', '67000', '711234526', 'No.76,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('851123427V', 'SADUNIKA', 'DISSANAYAKE ', '1985-01-28', 'F', '', '54000', '711234527', 'No.203,Wickrama Rd,Mortuwa');
INSERT INTO `employee` VALUES ('851123433V', 'TISHAN', 'FERNANDO ', '1985-02-03', 'M', '', '34560', '711234533', 'No.23,Kandy Rd,Panadura');
INSERT INTO `employee` VALUES ('851123434V', 'NIMANTHA', 'FERNANDO ', '1985-02-04', 'M', '', '45670', '711234534', 'No.203,Galle Rd,Balapitiya');
INSERT INTO `employee` VALUES ('851123436V', 'DUNISHA', 'FERNANDO ', '1985-02-06', 'F', '', '67000', '711234536', 'No.73/1,Wackwella Rd,Galle');
INSERT INTO `employee` VALUES ('851123442V', 'SACHINI', 'GUNASEKARA', '1985-02-12', 'F', '', '56000', '711234542', 'No.43,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('851123447V', 'BHAGYA', 'IDAMEGEDARA ', '1985-02-16', 'F', '', '56740', '711234546', 'No.70,Koswaththa,Baththaramulla');
INSERT INTO `employee` VALUES ('851123448V', 'FARA', 'JABIR ', '1985-02-17', 'F', '', '78000', '711234546', 'No.71,Bambalapitiya,Colombo');
INSERT INTO `employee` VALUES ('851123449V', 'RUWANI', 'JAYARATHNE ', '1985-02-18', 'F', '', '77000', '711234547', 'No,72,Wallawaththa,Colombo');
INSERT INTO `employee` VALUES ('851123450V', 'PRIYANWADA', 'JAYASINGHE ', '1985-02-19', 'F', '', '88000', '711234548', 'No.54,Polwaththa,Anbalangoda');
INSERT INTO `employee` VALUES ('851123451V', 'LAKSHAN', 'JAYASINGHE ', '1985-02-20', 'M', '', '89000', '711234549', 'No.53,Pokunuwita,Horana');
INSERT INTO `employee` VALUES ('851123452V', 'UDARI', 'JAYASINGHE ', '1985-02-21', 'F', '', '75000', '721234550', 'No.52,Wakwalla,galle');
INSERT INTO `employee` VALUES ('851123453V', 'PAWITHRA', 'JAYATHILAKE ', '1985-02-22', 'F', '', '46000', '771234551', 'No.51,Miriswaththa,Gampaha');
INSERT INTO `employee` VALUES ('851123454V', 'KAUSHIKA', 'JAYATUNGA ', '1985-02-23', 'F', '', '32000', '701234552', 'No.50,Kiridiwala,Gampaha');
INSERT INTO `employee` VALUES ('851123455V', 'IRESHA', 'JAYAWARDANA ', '1985-02-24', 'F', '', '31000', '761234553', 'No.49,Yatiyana,Mathugama');
INSERT INTO `employee` VALUES ('851123456V', 'ANUPAMA', 'ARUKGODA ', '1985-01-07', 'F', '', '21000', '701234566', 'No.59,Ratnayaka Rd,Dehiwala');
INSERT INTO `employee` VALUES ('851123457V', 'CHAMATH', 'KALHARA ', '1985-02-25', 'M', '', '45000', '771234554', 'No.48,Bataduwa,Galle');
INSERT INTO `employee` VALUES ('851123458V', 'CHAMARA', 'KALINDU ', '1985-02-26', 'M', '', '34000', '771234555', 'No.47,Alapitigala,Ragama');
INSERT INTO `employee` VALUES ('851123460V', 'ASANKA', 'KARIYAWASAM ', '1985-02-27', 'M', '', '45000', '771234556', 'No.46,Makubura,Kottawa');
INSERT INTO `employee` VALUES ('851123461V', 'CHETHANI', 'KARIYAWASAM', '1985-02-28', 'F', '', '67000', '771234557', 'No.45,Delthota,Kandy');
INSERT INTO `employee` VALUES ('851123462V', 'GOTHAMI', 'KARUNARATHNA ', '1985-03-01', 'F', '', '75000', '781234558', 'No.44,Imaduwa,Galle');
INSERT INTO `employee` VALUES ('851123463V', 'UPEKSHA', 'KARUNARATHNA ', '1985-03-02', 'F', '', '79000', '781234559', 'No.43,Kotahena,Colombo');
INSERT INTO `employee` VALUES ('851123464V', 'ANURADHI', 'KARUNARATHNE ', '1985-03-03', 'F', '', '59000', '711234560', 'No.42,Mapalagama,Galle');
INSERT INTO `employee` VALUES ('851123465V', 'HASIRU', 'KAVISHAN B.H.', '1985-03-04', 'M', '', '19000', '711234561', 'No.41Dompe,Gampaha');
INSERT INTO `employee` VALUES ('851123466V', 'NIPUN', 'KEGALLE ', '1985-03-05', 'M', '', '23000', '711234562', 'No.40,Alpitiya,Galle');
INSERT INTO `employee` VALUES ('851123467V', 'SAMEERA', 'KESHAN ', '1985-03-06', 'M', '', '10000', '761234563', 'No.39,Kakanadura,Matara');
INSERT INTO `employee` VALUES ('851123468V', 'SULOCHANA', 'KODITUWAKKU ', '1985-03-07', 'M', '', '34000', '711234564', 'No.38,Udugama,Galle');
INSERT INTO `employee` VALUES ('851123469V', 'BIMSARA', 'KOTHALAWALA', '1985-03-08', 'M', '', '56890', '711234565', 'No.37,Kaburugamuwa,Matara');
INSERT INTO `employee` VALUES ('851123470V', 'PRINSI', 'KULASOORIYA ', '1985-03-09', 'F', '', '56890', '721234566', 'No.36,Palatiyana,waligama');
INSERT INTO `employee` VALUES ('851123471V', 'AYESHA', 'KULATUNGA ', '1985-03-10', 'F', '', '73400', '711234567', 'No.35,Aluthgama,Kalutara');
INSERT INTO `employee` VALUES ('851123472V', 'DINESH', 'KUMARA', '1985-03-11', 'M', '', '56300', '771234568', 'No.34,Nagoda,Galle');
INSERT INTO `employee` VALUES ('851123473V', 'HASANGA', 'LAKMAL ', '1985-03-12', 'M', '', '23300', '711234569', 'No.33,Thalalla,Matara');
INSERT INTO `employee` VALUES ('851123474V', 'PASINDU', 'LAKMAL ', '1985-03-13', 'M', '', '23500', '711234570', 'No.32,Papiliyana,Boralasgamuwa');
INSERT INTO `employee` VALUES ('851123475V', 'MANUSHA', 'LAKMALI ', '1985-03-14', 'F', '', '7800', '771234571', 'No.31,Talwaththa,Kandy');
INSERT INTO `employee` VALUES ('851123476V', 'WATHSALA', 'LAKSHANI ', '1985-03-15', 'F', '', '50000', '771234572', 'No.30,Madiha,Matara');
INSERT INTO `employee` VALUES ('851123477V', 'LAKSHANI ', 'KULATHUNGA', '1985-03-16', 'F', '', '67000', '711234573', 'No.29,Hapugala,Galle');
INSERT INTO `employee` VALUES ('851123479V', 'DILUMI', 'LIYANAGE ', '1985-03-18', 'F', '', '43900', '711234575', 'No.27,Narammala,Kurunagala');
INSERT INTO `employee` VALUES ('851123480V', 'HASINI', 'LIYANAGE ', '1985-03-19', 'F', '', '34000', '711234576', 'No.26,Wariyapola,Kurunagala');
INSERT INTO `employee` VALUES ('851123481V', 'NADEESHIKA', 'MADANAYAKE  ', '1985-03-20', 'F', '', '65000', '711234577', 'N0.25,Uggalabada,Kalutara');
INSERT INTO `employee` VALUES ('851123482V', 'JANAKA', 'MADHUSANKHA', '1985-03-21', 'M', '', '89000', '751234578', 'No.24,Yatiyana,Matara');
INSERT INTO `employee` VALUES ('851123483V', 'NIMASHA', 'MADUMALI ', '1985-03-22', 'F', '', '65000', '711234579', 'No.23,Miriswaththa,Piliyandala');
INSERT INTO `employee` VALUES ('851123484V', 'ASHA', 'MADUSHANI ', '1985-03-23', 'F', '', '54000', '771234580', 'No.22,Dewalegama,Kegalle');
INSERT INTO `employee` VALUES ('851123485V', 'SAMPATH', 'MADUSHANKA ', '1985-03-24', 'M', '', '43000', '771234581', 'No.21,Randolugama,Seeduwa');
INSERT INTO `employee` VALUES ('851123486V', 'ISHANI', 'MADUWANTHI ', '1985-03-25', 'F', '', '32000', '781234582', 'N0.20,Katuwana,Walasmulla');
INSERT INTO `employee` VALUES ('851123487V', 'SHASHINI', 'MALEESHA ', '1985-04-01', 'F', '', '21000', '711234583', 'No.02,Abillawaththa,Boralasgamuwa');
INSERT INTO `employee` VALUES ('851123488V', 'PUBUDU', 'MALITH ', '1985-04-02', 'M', '', '43000', '711234584', 'No.03,Hiththatiya,Matara');
INSERT INTO `employee` VALUES ('851123489V', 'SURANGI', 'MANAMPERI', '1985-04-03', 'F', '', '87000', '721234585', 'No.04,Gothatuwa,Rajagiriya');
INSERT INTO `employee` VALUES ('851123490V', 'NUWAN', 'MANCHANAYAKA ', '1985-04-04', 'M', '', '45000', '711234586', 'No.05,Arawwala,Maharagama');
INSERT INTO `employee` VALUES ('851123491V', 'KOSALA', 'MARASINGHE ', '1985-04-05', 'M', '', '56990', '721234587', 'No.06,Gothatuwa,Rajagiriya');
INSERT INTO `employee` VALUES ('851123492V', 'VISHWA', 'MEEGALLA ', '1985-04-06', 'M', '', '56780', '711234588', 'No.07,Kirillawala,Kadawatha');
INSERT INTO `employee` VALUES ('851123493V', 'SHANEL', 'MENDIS ', '1985-04-07', 'M', '', '12340', '711234589', 'No.08,Makola,Gampaha');
INSERT INTO `employee` VALUES ('851123494V', 'NUWAN', 'DHANUSHKA', '1985-04-08', 'M', '', '23450', '711234590', 'No.09,Imaduwa,Galle');
INSERT INTO `employee` VALUES ('851123495V', 'HAYESHA', 'JAYAMINI', '1985-04-09', 'F', '', '34560', '771234591', 'No.10,Ragama,Kadawata');
INSERT INTO `employee` VALUES ('851123496V', 'ANUKI', 'THULARA', '1985-04-10', 'F', '', '45670', '711234592', 'No.11,Asgiriya,Kandy');
INSERT INTO `employee` VALUES ('851123497V', 'PIYUMI', 'APSARA', '1985-04-11', 'F', '', '56780', '761234593', 'No.12,Ibbagamuwa,Kurunagala');
INSERT INTO `employee` VALUES ('851123498V', 'THILINI', 'MUDALIGE ', '1985-04-12', 'F', '', '67890', '711234594', 'No.13,Dewundara,Matara');
INSERT INTO `employee` VALUES ('851123499V', 'MAYUMI', 'NIMSARA', '1985-04-13', 'F', '', '78900', '751234595', 'No.14,Palathota,kalutara');
INSERT INTO `employee` VALUES ('855123412V', 'NILUSHAN', 'COSTA ', '1985-01-13', 'M', '', '45000', '711234512', 'No.168/B,Abeysundara Rd,Kalutara');
INSERT INTO `employee` VALUES ('855123413V', 'MADAWA', 'DABARE ', '1985-01-14', 'M', '', '12000', '711234513', 'No.203,Galle Rd,Kalutara');
INSERT INTO `employee` VALUES ('855123414V', 'LAKSHAN', 'DASANAYAKE', '1985-01-15', 'M', '', '13400', '711234514', 'No.203,Galle Rd,Ratmalana');
INSERT INTO `employee` VALUES ('855123415V', 'RUWAN', 'DASSANAYAKE ', '1985-01-16', 'M', '', '15000', '711234515', 'No.200,Galle Rd,Moratuwa');
INSERT INTO `employee` VALUES ('855123416V', 'KASUN', 'DE SILVA ', '1985-01-17', 'M', '', '34000', '711234516', 'No.24,Katubedda,Moratuwa');
INSERT INTO `employee` VALUES ('855123417V', 'NUWAN', 'DE SILVA ', '1985-01-18', 'M', '', '35000', '711234517', 'No.78,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('855123418V', 'MAHESH', 'DE SOYSA ', '1985-01-19', 'M', '', '36000', '721234518', 'No.23,Vihara Rd,Panadura');
INSERT INTO `employee` VALUES ('855123419V', 'NIPUN', 'DEEMANTHA ', '1985-01-20', 'M', '', '29000', '771234519', 'No.33,Galle Rd,Ratmalana');
INSERT INTO `employee` VALUES ('855123420V', 'CHALITH', 'DESAMAN ', '1985-01-21', 'M', '', '41000', '771234520', 'No.03,Galle Rd,Moratuwa');
INSERT INTO `employee` VALUES ('855123421V', 'SUBHASH', 'DEVANARAYANA ', '1985-01-22', 'M', '', '45500', '711234521', 'No.90,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('855123422V', 'LAHIRU', 'DHANANJAYA ', '1985-01-23', 'M', '', '21400', '711234522', 'No.83,Gunawardana Rd,Panadura');
INSERT INTO `employee` VALUES ('855123423V', 'THARINDU', 'DHANANJAYA ', '1985-01-24', 'M', '', '67950', '711234523', 'No.2/C,Godage Mw,Panadura');
INSERT INTO `employee` VALUES ('855123428V', 'CHISHAN', 'EDIRISINGHE ', '1985-01-29', 'M', '', '55000', '711234528', 'No.20,Galle Rd,Wellawatta');
INSERT INTO `employee` VALUES ('855123429V', 'SUNETH', 'EDIRISOORIYA ', '1985-01-30', 'M', '', '31000', '711234529', 'No.28,Galle Rd,Colombo 3');
INSERT INTO `employee` VALUES ('855123430V', 'DILANI', 'EDIRISINGHE ', '1985-01-31', 'F', '', '31467', '711234530', 'No.20,Kurunduwatta Rd,Colombo 7');
INSERT INTO `employee` VALUES ('855123431V', 'CHATHURA', 'ELLAWALA ', '1985-02-01', 'M', '', '56780', '711234531', 'No.23,Samara Rd,Panadura');
INSERT INTO `employee` VALUES ('855123435V', 'RUSIRU', 'FERNANDO ', '1985-02-05', 'M', '', '34800', '711234535', 'No.53,Galle Rd,Ahungalla');
INSERT INTO `employee` VALUES ('855123437V', 'MADURA', 'GAMAGE ', '1985-02-07', 'M', '', '43000', '711234537', 'No.203,Galle Rd,Matara');
INSERT INTO `employee` VALUES ('855123438V', 'KANISHKA', 'GAYAN ', '1985-02-08', 'M', '', '45000', '711234538', 'No.23/9,Gunasekara Rd,Panadura');
INSERT INTO `employee` VALUES ('855123439V', 'ISHIKA', 'GODAGE ', '1985-02-09', 'M', '', '89000', '711234539', 'No.20,Galle Rd,Matara');
INSERT INTO `employee` VALUES ('855123440V', 'ERANDA', 'GUNATHILAKA ', '1985-02-10', 'M', '', '90000', '711234540', 'No.23,Kandy Rd,Kurunegala');
INSERT INTO `employee` VALUES ('855123441V', 'BHASURA', 'GUNAWARDHANA ', '1985-02-11', 'M', '', '95000', '711234541', 'No.2B,Galle Rd,Polgahawela');
INSERT INTO `employee` VALUES ('855123443V', 'SUMUDU', 'HASARANDA ', '1985-02-13', 'M', '', '57000', '711234543', 'No.67,Alpitiya,Galle');
INSERT INTO `employee` VALUES ('855123445V', 'MADAWA', 'HERATH ', '1985-02-14', 'M', '', '34000', '711234544', 'No.68,Waligama,Matara');
INSERT INTO `employee` VALUES ('855123446V', 'PUBUDU', 'HERATH ', '1985-02-15', 'M', '', '41900', '711234545', 'No.69,Horana Rd,Padukka');
INSERT INTO `employee` VALUES ('855123451V', 'THARIDU', 'ABEYWICKRAMA ', '1985-01-02', 'M', '', '25000', '771234561', 'No.168/B,Abeysundara Rd,Kalutara');
INSERT INTO `employee` VALUES ('855123453V', 'NUSHRI', 'AHAMED ', '1985-01-04', 'M', '', '25600', '721234563', 'No.45,Asoka Rd,Maharagama');
INSERT INTO `employee` VALUES ('855123454V', 'SHEHAN', 'ANURUDDHA ', '1985-01-05', 'M', '', '30000', '761234564', 'No.55,Mihiri Uyana,Nugegoda');
INSERT INTO `employee` VALUES ('855123455V', 'NILAKSHA', 'ARIYASIRI  ', '1985-01-06', 'M', '', '33300', '751234565', 'No.89,Temple Rd,Ratmalana');
INSERT INTO `employee` VALUES ('855123457V', 'DIMUTHU', 'ATHUKORALA ', '1985-01-08', 'M', '', '40000', '711234567', 'No.93,Frazer Rd,Mt.Lavinia');
INSERT INTO `employee` VALUES ('855123458V', 'KAVEESHA', 'BADDAGE ', '1985-01-09', 'M', '', '51000', '711234568', 'No.203,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('855123459V', 'HESHAN', 'BATAWALAARACHCHI ', '1985-01-10', 'M', '', '18000', '711234569', 'No.203,Galle Rd,Panadura');
INSERT INTO `employee` VALUES ('931678987V', 'dulaj', 'sanjaya', '1993-05-21', 'M', '', '3400000', '713018948', 'No 22, xroad, maharagama ');
INSERT INTO `employee` VALUES ('931881477V', 'nadun', 'indunil', '1993-04-21', 'M', '', '30000', '713018949', 'NO 32, yatiyana, Mathara');
INSERT INTO `employee` VALUES ('931991476V', 'shann', 'Lakshitha', '1993-11-23', 'M', '', '20000', '713018945', 'No 22, flower road, colombo 07');
INSERT INTO `employee` VALUES ('931991478V', 'THILINI', 'VIDANAPATIRANA', '1985-04-14', 'F', '', '34000', '771234546', 'No.15,Mamadala,Ambalantota');
